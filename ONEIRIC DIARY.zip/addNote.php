<?php
// Including the configuration file
include("config.php");

// Checking if the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Checking if both note title and content are set in the POST data
    if (isset($_POST['note_title'], $_POST['note_content'])) {
        // Extracting note title and content from POST data
        $noteTitle = $_POST['note_title'];
        $noteContent = $_POST['note_content'];
        // Generating the current date and time
        $dateUploaded = date("Y-m-d H:i:s");

        try {
            // Preparing SQL statement to insert a new note into the database
            $stmt = $conn->prepare("INSERT INTO notes (note_title, note_content, date_posted) VALUES (?, ?, ?)");

            // Binding parameters to the SQL statement
            $stmt->bind_param('sss', $noteTitle, $noteContent, $dateUploaded);

            // Executing the SQL statement
            $stmt->execute();

            // Displaying a success alert and redirecting to the notes page
            echo "
            <script>
                alert('Added Successfully!');
                window.location.href = 'http://localhost/simpleapp/notes.php';
            </script>
            ";
            // Exiting the script after redirection
            exit();
        } catch (mysqli_sql_exception $e) {
            // Displaying a database error message if an exception occurs
            echo 'Database Error: ' . $e->getMessage();
        }
    } else {
        // Displaying an alert if either the title or content fields are empty
        echo "
        <script>
            alert('Please fill in both the title and content fields.');
            window.location.href = 'http://localhost/simpleapp/notes.php';
        </script>
        ";
    }
}
?>

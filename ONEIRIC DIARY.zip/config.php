<?php
    // Establish a connection to the MySQL database
    $conn = mysqli_connect("localhost", "root", "", "register");

    // Check for connection errors
    if (mysqli_connect_errno()) {
        // Terminate the script and display an error message
        die("Failed to connect to MySQL: " . mysqli_connect_error());
    }

    // Optionally, make the database connection global (not typically necessary)
    global $conn;
?>

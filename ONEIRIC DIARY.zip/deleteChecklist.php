<?php 
// Include the database configuration file
include("config.php");

// Check if the checklist ID is set in the GET parameters
if (isset($_GET['checklists'])) {
    // Get the checklist ID from the GET parameters
    $checklistID = $_GET['checklists'];

    // Try to delete the checklist from the database
    try {
        // SQL query to delete the checklist with a specific ID
        $query = "DELETE FROM `checklists` WHERE `tbl_checklist_id` = ?";
        $stmt = $conn->prepare($query);

        // Bind the checklist ID parameter
        $stmt->bind_param("i", $checklistID);

        // Execute the query and check if it was successful
        $query_execute = $stmt->execute();

        // Display appropriate messages based on the query result
        if ($query_execute) {
            echo "
            <script>
                alert('Checklist Deleted Successfully!');
                window.location.href = 'http://localhost/simpleapp/checklists.php'; // Redirect to the appropriate page
            </script>
            ";
        } else {
            echo "
            <script>
                alert('Failed to Delete Checklist!');
                window.location.href = 'http://localhost/simpleapp/checklists.php'; // Redirect to the appropriate page
            </script>
            ";
        }
    } catch (PDOException $e) {
        // Display an error message if an exception occurs
        echo "Error: " . $e->getMessage();
    }
}
?>

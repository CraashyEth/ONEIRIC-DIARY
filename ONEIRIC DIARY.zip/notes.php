<?php 
// Including the configuration file
include("config.php")
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Journal</title>
    <!-- Linking external stylesheet for notes -->
    <link rel="stylesheet" href="assets/notes.css"> 

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" />

</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-light ">
        <!-- Journal brand/logo in the navbar -->
        <a class="navbar-brand ml-4" href="#">My Journal</a>
        <!-- Button to toggle navigation menu on small screens -->
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <!-- Navigation Menu -->
        <div class="collapse navbar-collapse ml-4" id="navbarNavAltMarkup">
            <div class="navbar-nav">
                <!-- Button to trigger the 'Add Note' modal -->
                <a class="nav-link" href="" data-toggle="modal" data-target="#addNoteModal">Add Note</a>
            </div>
            <!-- Right-aligned navigation links -->
            <div class="navbar-nav ml-auto">
                <a href="home.php" class="nav-link">Home</a>
                <a href="checklists.php" class="nav-link">Checklists</a>
            </div>
        </div>
    </nav>

    <!-- Add Note Modal -->
    <div class="modal fade mt-5" id="addNoteModal" tabindex="-1" aria-labelledby="addNote" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <!-- Modal Title -->
                    <h5 class="modal-title" id="addNote">Add Note</h5>
                    <!-- Close button for the modal -->
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <!-- Form to add a new note -->
                    <form action="addNote.php" method="POST">
                        <!-- Input for note title -->
                        <div class="form-group">
                            <label for="noteTitle">Note Title</label>
                            <input type="text" class="form-control" id="noteTitle" name="note_title">
                        </div>
                        <!-- Textarea for note content -->
                        <div class="form-group">
                            <label for="noteContent">Note</label>
                            <textarea class="form-control" name="note_content" id="noteContent" cols="30" rows="10"></textarea>
                        </div>
                        <!-- Modal footer with close and save changes buttons -->
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-dark">Save changes</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- View Note Modal -->
    <div class="modal fade mt-5" id="viewNoteModal" tabindex="-1" aria-labelledby="viewNote" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content note-modal">
                <div class="modal-body">
                    <!-- Header with title and edit button -->
                    <div class="header row">
                        <h1 class="modal-title ml-4" id="viewNote" style="width:83%">Note</h1>
                        <div class="btn-group mr-2 float-right" role="group" aria-label="First group">
                            <!-- Edit button -->
                            <button type="button" class="btn" id="editModal"><i class="fa-solid fa-pencil"></i></button>
                        </div>
                    </div>
                    <!-- Form to edit an existing note -->
                    <div class="view-note-content">
                        <form action="updateNote.php" method="POST">
                            <!-- Hidden input for note ID -->
                            <input type="text" class="form-control" id="noteModalID" name="tbl_note_id" hidden>
                            <!-- Input for note title (readonly) -->
                            <div class="form-group">
                                <label for="noteModalTitle">Title:</label>
                                <input type="text" class="form-control" id="noteModalTitle" name="note_title" style="border:none;" readonly>
                            </div>
                            <!-- Textarea for note content (readonly) -->
                            <div class="form-group">
                                <label for="noteModalContent">Content:</label>
                                <textarea class="form-control" name="note_content" id="noteModalContent" cols="30" rows="8" style="border: none;" readonly></textarea>
                            </div>
                            <!-- Display date posted and edit buttons -->
                            <small class="float-right" id="datePosted"></small>
                            <div class="float-right" id="edit-buttons" style="display:none">
                                <button type="button" class="btn btn-secondary edit-button" data-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-dark edit-button">Save changes</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Main content area to display notes -->
    <div class="main row">
        <?php
        // Fetching and displaying notes from the database
        $stmt = $conn->prepare("SELECT * FROM `notes`");
        $stmt->execute();
        $result = $stmt->get_result();

        foreach ($result as $row) {
            // Extracting note details from the result
            $noteID = isset($row["tbl_note_id"]) ? $row["tbl_note_id"] : null;
            $noteTitle = isset($row["note_title"]) ? $row["note_title"] : null;
            $noteContent = isset($row["note_content"]) ? $row["note_content"] : null;
            $datePosted = isset($row["date_posted"]) ? $row["date_posted"] : null;
        ?>
            <!-- Note container with content and delete button -->
            <div class="note-container" onclick="viewNote(<?= $noteID ?>)">
                <button type="button" class="btn float-right mt-2 mr-2" id="deleteModal">
                    <!-- Delete button with Font Awesome icon -->
                    <i class="fa-solid fa-x" onclick="deleteNote(<?= $noteID ?>)"></i>
                </button>
                <!-- Hidden paragraph elements with note details -->
                <div class="note-content">
                    <p id="noteID-<?= $noteID ?>" hidden><?= $noteID ?></p>
                    <p id="noteTitle-<?= $noteID ?>" hidden><?= $noteTitle ?></p>
                    <p id="noteContent-<?= $noteID ?>"><?= $noteContent ?></p>
                    <p id="datePosted-<?= $noteID ?>" hidden><?= $datePosted ?></p>
                </div>
            </div>
        <?php 
        }
        ?>
    </div>

    <!-- JavaScript libraries -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.min.js"></script>

    <!-- Custom JavaScript -->
    <script src="assets/script.js"></script>
</body>
</html>

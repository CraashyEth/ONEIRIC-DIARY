<?php
// Include the configuration file for database connection
include("config.php");

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if the necessary POST parameters are set
    if (isset($_POST['checklist_title'], $_POST['checklists'])) {
        // Get checklist title and items from POST data
        $checklistTitle = $_POST['checklist_title'];
        $checklistItems = implode(', ', $_POST['checklists']);
        $dateUploaded = date("Y-m-d H:i:s");

        // Try to insert checklist data into the database
        try {
            // Prepare SQL statement for insertion
            $stmt = $conn->prepare("INSERT INTO checklists (checklist_title, checklist_content, date_posted) VALUES (?, ?, ?)");

            // Bind parameters to the prepared statement
            $stmt->bind_param('sss', $checklistTitle, $checklistItems, $dateUploaded);

            // Execute the prepared statement
            $stmt->execute();

            // Display success message and redirect on successful insertion
            echo "
            <script>
                alert('Checklist Added Successfully!');
                window.location.href = 'http://localhost/simpleapp/checklists.php';
            </script>
            ";
            exit();
        } catch (mysqli_sql_exception $e) {
            // Display database error message on exception
            echo 'Database Error: ' . $e->getMessage();
        }
    } else {
        // Display an alert if checklist title and items are not provided
        echo "
        <script>
            alert('Please fill in both the checklist title and items.');
            window.location.href = 'http://localhost/simpleapp/checklists.php';
        </script>
        ";
    }
}
?>

<?php
// Include the database configuration file
include("config.php");

// Check if the 'note' parameter is set in the GET parameters
if (isset($_GET['note'])) {
    // Get the note ID from the GET parameters
    $note = $_GET['note'];

    // Try to delete the note from the database
    try {
        // SQL query to delete the note with a specific ID
        $query = "DELETE FROM `notes` WHERE `tbl_note_id` = '$note'";
        $stmt = $conn->prepare($query);

        // Execute the query and check if it was successful
        $query_execute = $stmt->execute();

        // Display appropriate messages based on the query result
        if ($query_execute) {
            echo "
            <script>
                alert('Note Deleted Successfully!');
                window.location.href = 'http://localhost/simpleapp/notes.php';
            </script>
            ";
        } else {
            echo "
            <script>
                alert('Failed to Delete Note!');
                window.location.href = 'http://localhost/simpleapp/notes.php';
            </script>
            ";
        }

    } catch (PDOException $e) {
        // Display an error message if an exception occurs
        echo "Error: " . $e->getMessage();
    }
}
?>

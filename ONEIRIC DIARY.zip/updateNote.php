<?php
// Include your config.php file to establish a database connection
include("config.php");

// Check if the form was submitted using the POST method
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if the required form fields are set
    if (isset($_POST['note_title'], $_POST['note_content'])) {
        // Retrieve values from the form
        $noteID = $_POST['tbl_note_id'];
        $noteTitle = $_POST['note_title'];
        $noteContent = $_POST['note_content'];
        
        // Get the current date and time
        $datePosted = date("Y-m-d H:i:s"); 

        try {
            // Prepare an SQL statement for updating the notes
            $stmt = $conn->prepare("UPDATE `notes` SET `note_title` = ?, `note_content` = ?, `date_posted` = ? WHERE `tbl_note_id` = ?");

            // Bind parameters to the prepared statement
            $stmt->bind_param('sssi', $noteTitle, $noteContent, $datePosted, $noteID);

            // Execute the prepared statement
            $stmt->execute();

            // Display a success message and redirect on successful update
            echo "
            <script>
                alert('Updated Successfully!');
                window.location.href = 'http://localhost/simpleapp/notes.php';
            </script>
            ";
            exit();
        } catch (Exception $e) {
            // Log the error details for debugging
            echo 'Database Error: ' . $e->getMessage();
        }
    } else {
        // Display an alert if required form fields are not set
        echo "
        <script>
            alert('Please fill in both the title and content fields.');
            window.location.href = 'http://localhost/simpleapp/notes.php';
        </script>
        ";
    }
}
?>

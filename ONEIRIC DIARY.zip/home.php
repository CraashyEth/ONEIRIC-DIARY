<?php
// Start the session for user authentication
session_start();

// Include the database configuration file
include("config.php");

// Check if the user is not logged in, redirect to the login page
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

// Get the user ID from the session
$user_id = $_SESSION['user_id'];

// Retrieve user's first name from the database
$user_query = "SELECT fname FROM journal WHERE id = $user_id";
$user_result = mysqli_query($conn, $user_query);
$user_data = mysqli_fetch_assoc($user_result);
$first_name = $user_data['fname'];

// Retrieve notes for the logged-in user from the database
$notes_query = "SELECT * FROM notes WHERE user_id = $user_id";
$notes_result = mysqli_query($conn, $notes_query);

// Retrieve checklists for the logged-in user from the database
$checklists_query = "SELECT * FROM checklists WHERE user_id = $user_id";
$checklists_result = mysqli_query($conn, $checklists_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Meta tags for document information -->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge"> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0" >
    <title>2-2</title> 

    <!-- CSS file links -->
    <link rel="stylesheet" type="text/css" href="assets/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css">
</head>

<body style="background: url(whitebg.jpg);background-size: 100% 100%;" body text="#461959">
    <!-- Header section -->
    <header class="header">
        <img src="" id="complogo1">
        <h1 class="logo"><a href="#"><?php echo $first_name; ?>'s Journal</a></h1>
        <!-- Navigation links -->
        <ul class="main-nav">
            <li><a href="#Home">Home</a></li>
            <li><a class="logout" href="index.php">Log Out</a></li>
        </ul>
    </header>

    <!-- Home section with parallax effect -->
    <div class="wrapper">
        <main>
            <section class="module parallax parallax-1" id="Home">
                <h1>ONEIRIC DIARY</h1>
                <!-- Button container with links to Notes and Checklists pages -->
                <div class="button-container">
                    <a class="button" href="notes.php">Notes</a>
                    <a class="button" href="checklists.php">Checklists</a>
                </div>
                <!-- Footer with developer information -->
                <footer class="footer">    
                    <p>Developed by Group 6 - PHP Group </p>
                </footer>
            </section>
        </main>
    </div>    
</body>
</html>

<?php
// Close the database connection
mysqli_close($conn);
?>

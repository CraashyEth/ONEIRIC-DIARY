<?php
// Include the configuration file for database connection
include("config.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Meta tags and title for the document -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Journal</title>

    <!-- External CSS stylesheets and libraries -->
    <link rel="stylesheet" href="assets\checklist.css"> 
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" />
</head>
<body>
    <!-- Navigation bar -->
    <nav class="navbar navbar-expand-lg navbar-light ">
        <!-- Brand/logo and toggle button for small screens -->
        <a class="navbar-brand ml-4" href="#">My Journal</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        
        <!-- Navigation links -->
        <div class="collapse navbar-collapse ml-4" id="navbarNavAltMarkup">
            <div class="navbar-nav">
                <!-- Modal trigger to add a checklist -->
                <a class="nav-link" href="" data-toggle="modal" data-target="#addChecklistModal">Add Checklist</a>
            </div>
            <div class="navbar-nav ml-auto">
                <!-- Navigation links to other sections -->
                <a href="home.php" class="nav-link">Home</a>
                <a href="notes.php" class="nav-link">Notes</a>
            </div>
        </div>
    </nav>

    <!-- Modal for adding a checklist -->
    <div class="modal fade mt-5" id="addChecklistModal" tabindex="-1" aria-labelledby="addChecklist" aria-hidden="true">
        <!-- Modal dialog for adding a checklist -->
        <div class="modal-dialog">
            <div class="modal-content">
                <!-- Modal header with title and close button -->
                <div class="modal-header">
                    <h5 class="modal-title" id="addChecklist">Add Checklist</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <!-- Modal body with a form for adding a checklist -->
                <div class="modal-body">
                    <form action="addChecklist.php" method="POST">
                        <!-- Form fields for checklist title and items -->
                        <div class="form-group">
                            <label for="checklistTitle">Checklist Title</label>
                            <input type="text" class="form-control" id="checklistTitle" name="checklist_title">
                        </div>
                        <div class="form-group">
                            <label for="checklistInput">Checklist Items</label>
                            <!-- Input field and button for adding checklist items -->
                            <input type="text" class="form-control" id="checklistInput" name="checklistInput" placeholder="Enter checklist item" onkeydown="if (event.keyCode == 13) addChecklistItem()">
                            <button type="button" class="btn btn-secondary mt-2" onclick="addChecklistItem()">Add Item</button>
                            <!-- Container to display added checklist items -->
                            <div id="checklistItems"></div>
                            <!-- Hidden input to store checklist items for form submission -->
                            <input type="hidden" name="checklists[]" id="checklistHidden">
                        </div>
                        <!-- Modal footer with close and save changes buttons -->
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-dark">Save changes</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Main content area displaying existing checklists -->
    <div class="main row">
        <?php
        // Retrieve checklists from the database
        $stmt = $conn->prepare("SELECT * FROM `checklists`");
        $stmt->execute();
        $result = $stmt->get_result();

        // Iterate through checklists and display them
        foreach ($result as $row) {
            $checklistID = isset($row["tbl_checklist_id"]) ? $row["tbl_checklist_id"] : null;
            $checklistTitle = isset($row["checklist_title"]) ? $row["checklist_title"] : null;
            $checklistContent = isset($row["checklist_content"]) ? $row["checklist_content"] : null;
        ?>

        <!-- Container for each checklist item -->
        <div class="checklist-container">
            <!-- Button to delete a checklist item -->
            <button type="button" class="btn float-right mt-2 mr-2" id="deleteModal">
                <!-- Icon for delete action -->
                <i class="fa-solid fa-x" onclick="deleteChecklist(<?= $checklistID ?>)"></i>
            </button>
            <!-- Container for checklist content -->
            <div class="checklist-content">
                <!-- Hidden paragraph for checklist ID -->
                <p id="checklistID-<?= $checklistID ?>" hidden><?= $checklistID ?></p>
                <!-- Display checklist title -->
                <p id="checklistTitle-<?= $checklistID ?>"><?= $checklistTitle ?></p>
                <!-- Hidden paragraph for checklist content -->
                <p id="checklistContent-<?= $checklistID ?>" hidden><?= $checklistContent ?></p>

                <!-- Display checklist items as an unordered list -->
                <ul>
                    <?php
                    $items = explode(',', $checklistContent);
                    foreach ($items as $item) {
                        echo "<li>$item</li>";
                    }
                    ?>
                </ul>
            </div>
        </div>

        <?php 
        }
        ?>
    </div>

    <!-- External JavaScript libraries for functionality -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.min.js"></script>

    <!-- Inline JavaScript for checklist-related functions -->
    <script>
        // Function to add a checklist item
        function addChecklistItem() {
            // Get the value of the checklist input
            const checklistInput = document.getElementById("checklistInput").value;

            // Check if the input is not empty
            if (checklistInput.trim() !== "") {
                // Create a list item and set its content
                const listItem = document.createElement("li");
                listItem.textContent = checklistInput;

                // Append the list item to the checklist items container
                const checklistItems = document.getElementById("checklistItems");
                checklistItems.appendChild(listItem);

                // Update the hidden input with the checklist items
                updateHiddenChecklist();
                
                // Clear the checklist input field
                document.getElementById("checklistInput").value = "";
            }
        }

        // Function to update the hidden input with checklist items
        function updateHiddenChecklist() {
            // Get all list items within the checklist items container
            const checklistItems = document.getElementById("checklistItems").getElementsByTagName("li");

            // Create an array to store checklist items
            const itemsArray = [];

            // Iterate through list items and add their content to the array
            for (let i = 0; i < checklistItems.length; i++) {
                itemsArray.push(checklistItems[i].textContent);
            }

            // Set the value of the hidden input to the joined checklist items
            document.getElementById("checklistHidden").value = itemsArray.join(",");
        }

        // Function to confirm and delete a checklist
        function deleteChecklist(id) {
            if (confirm("Do you want to delete this checklist?")) {
                // Redirect to the deleteChecklist.php with the checklist ID
                window.location = "deleteChecklist.php?checklists=" + id;
            }
        }

        // Function to open the edit checklist modal
        function editChecklist(id) {
            $("#editChecklistModal").modal("show");

            // Get checklist title and items for editing
            let checklistTitle = $("#checklistTitle-" + id).text();
            let checklistItems = $("#checklistContent-" + id).text();

            // Set values in the edit checklist modal
            $("#editChecklistTitle").val(checklistTitle);
            $("#editChecklistInput").val(checklistItems);
            $("#editChecklistID").val(id);
        }
    </script>

    <!-- External JavaScript file for additional functionality -->
    <script src="assets\script2.js"></script>
</body>
</html>

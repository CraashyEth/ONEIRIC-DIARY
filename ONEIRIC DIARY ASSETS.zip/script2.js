// Execute the following code once the DOM content is fully loaded
document.addEventListener("DOMContentLoaded", function () {
    // Retrieve the editChecklistButton by its ID
    const editChecklistButton = document.getElementById("editChecklist");

    // Add an event listener to the editChecklistButton to trigger toggleEditChecklist function
    if (editChecklistButton) {
        editChecklistButton.addEventListener("click", toggleEditChecklist);
    }

    // Function to toggle the edit mode for checklist title and items
    function toggleEditChecklist() {
        // Retrieve DOM elements related to the checklist
        const checklistTitleInput = document.getElementById("checklistTitle");
        const checklistInput = document.getElementById("checklistInput");
        const checklistDatePosted = document.getElementById("checklistDatePosted");
        const editChecklistButtons = document.getElementById("edit-checklist-buttons");

        // Check if the required elements exist
        if (checklistTitleInput && checklistInput && checklistDatePosted && editChecklistButtons) {
            // Toggle read-only mode and adjust styles based on the current state
            if (checklistTitleInput.readOnly && checklistInput.readOnly) {
                // Enable edit mode
                checklistTitleInput.readOnly = false;
                checklistInput.readOnly = false;
                checklistDatePosted.style.display = "none";
                editChecklistButtons.style.display = "";
                checklistTitleInput.style.border = "";
                checklistInput.style.border = "";
            } else {
                // Disable edit mode
                checklistTitleInput.readOnly = true;
                checklistInput.readOnly = true;
                checklistDatePosted.style.display = "";
                editChecklistButtons.style.display = "none";
                checklistTitleInput.style.border = "none";
                checklistInput.style.border = "none";
            }
        }
    }

    // Function to view checklist details in a modal
    function viewChecklist(id) {
        // Show the modal using jQuery
        $("#editChecklistModal").modal("show");

        // Retrieve checklist details using jQuery selectors
        let checklistTitle = $("#checklistTitle-" + id).text();
        let checklistItems = $("#checklistContent-" + id).text();

        // Populate the modal with checklist details
        $("#editChecklistTitle").val(checklistTitle);
        $("#editChecklistInput").val(checklistItems);
        $("#editChecklistID").val(id);
    }

    // Function to confirm and delete a checklist
    function deleteChecklist(id) {
        // Ask for confirmation using the browser's confirm dialog
        if (confirm("Do you want to delete this checklist?")) {
            // Redirect to the deleteChecklist.php script with the checklist ID
            window.location = "deleteChecklist.php?checklists=" + id;
        }
    }
});

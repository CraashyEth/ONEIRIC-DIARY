// Function to toggle the edit mode for note title and content
function toggleEdit() {
    // Retrieve DOM elements
    const noteTitleInput = document.getElementById("noteModalTitle");
    const noteContentTextarea = document.getElementById("noteModalContent");
    const editModalButton = document.getElementById("editModal");
    const datePosted = document.getElementById("datePosted");
    const editButtons = document.getElementById("edit-buttons");

    // Check if the required elements exist
    if (noteTitleInput && noteContentTextarea && editModalButton) {
        // Toggle read-only mode and adjust styles based on current state
        if (noteTitleInput.readOnly && noteContentTextarea.readOnly) {
            // Enable edit mode
            noteTitleInput.readOnly = false;
            noteContentTextarea.readOnly = false;
            datePosted.style.display = "none";
            editButtons.style.display = "";
            noteTitleInput.style.border = "";
            noteContentTextarea.style.border = "";
        } else {
            // Disable edit mode
            noteTitleInput.readOnly = true;
            noteContentTextarea.readOnly = true;
            datePosted.style.display = "";
            editButtons.style.display = "none";
            noteTitleInput.style.border = "none";
            noteContentTextarea.style.border = "none";
        }
    }
}

// Add an event listener to the editModalButton to trigger toggleEdit function
const editModalButton = document.getElementById("editModal");
if (editModalButton) {
    editModalButton.addEventListener("click", toggleEdit);
}

// Function to view note details in a modal
function viewNote(id) {
    // Show the modal using jQuery
    $("#viewNoteModal").modal("show");

    // Retrieve note details using jQuery selectors
    let noteModalID = $("#noteID-" + id).text();
    let noteModalTitle = $("#noteTitle-" + id).text();
    let noteModalContent = $("#noteContent-" + id).text();
    let datePosted = $("#datePosted-" + id).text();

    // Log datePosted to the console
    console.log(datePosted);

    // Populate the modal with note details
    $("#noteModalID").val(noteModalID);
    $("#noteModalTitle").val(noteModalTitle);
    $("#noteModalContent").html(noteModalContent);
    $("#datePosted").html("Date Updated: " + datePosted);
}

// Function to confirm and delete a note
function deleteNote(id) {
    // Ask for confirmation using the browser's confirm dialog
    if (confirm("Do you want to delete this note?")) {
        // Redirect to the deleteNote.php script with the note ID
        window.location = "deleteNote.php?note=" + id;
    }
}
